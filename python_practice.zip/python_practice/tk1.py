from tkinter import *
from tkinter import ttk

root = Tk()

# ttk.Button(root, text="Login").grid()

root.mainloop()
# OOP, object oriented programming

student1_name = "Ram"
student1_marks = [45, 56, 78]

# student2_name = "Hari"
# student2_marks = [50, 46, 70]

# student3_name = "Shyam"
# student3_marks = [34, 67, 76]


# def total_marks(marks):
# #     print("Total marks = ", sum(marks))
#         return sum(marks)
    
    
# print(student1_name, f"Total Marks = {total_marks(student1_marks)}")
# print("Ram", None)
# print("Ram", "Total Marks = 179")


# class Student:
#     def __init__(self, name, marks):
#         self.name = name
#         self.marks = marks
        
#     def total_marks(self):
        # print("Total Marks = ", sum(self.marks))
        
    

# ram = Student("Ram", [45, 56, 78])
# hari = Student("Hari", [50, 46, 70])
# shyam = Student("Shyam", [34, 67, 76])

# print(type(ram))
# ram.total_marks()
# shyam.total_marks()
# hari.total_marks()

# a = 5 # => object?? class int
# a.upper() # wrong
# # print(type(a))
# name = "ram"  # object?? class str
# name.upper()
# print(type(name))

# l = [1,2 , 3]
# l.append()

# t  = (1, 2, 4)
# t.append()

# s = {1,2 , 4}
# s.add()

# d = {1:"a"}

# d.keys()
# d.values()
# d.items()

# 2 + 3 = 5
# "2" + "3" = "23"
# [1, 2] + [3,4] = [1,2,3,4]
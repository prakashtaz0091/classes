# Inheritance
# 
# class User: # Parent class / Super class
#     def __init__(self, name, address):
#         self.name = name
#         self.address = address
        
#     def show_info(self):
#         print(f"""
#             Name: {self.name}  
#             Address: {self.address}""")    


# class Student(User): # Child class / sub class
#     def __init__(self, name, address, grade): # method overriding
#         super().__init__(name, address)
#         self.grade = grade

#     def show_info(self): # method overriding
#         super().show_info()
#         print(f"Studies in {self.grade}")


# class Teacher(User): # Child class / sub class
#     def __init__(self, name, address, department, salary): # method overriding
#         super().__init__(name, address)
#         self.department = department
#         self.salary = salary
        
#     def show_info(self):
#         print(f"""
#         --------Teacher Information---------      
#             Name: {self.name}
#             Address: {self.address}
#             Department: {self.department}
#             Salary: Rs. {self.salary}
#         ------------------------------------
#               """)
        

# class Staff(User): # Child class / sub class
#     pass
#     # To-do
#     # add new attributes like, department, shift (eg. day, night), salary


# ram = Student("Ram Thapa", "KTM", "Grade 8")  
# hari = Teacher("Hari Thapa", "BTM", "Physics", 90000)  
# shyam = Staff("Shyam Thapa", "PKH")  



# # polymorphism

# ram.show_info()
# hari.show_info()
# shyam.show_info()

# 2 + 3
# "2" + "3"


# class Point:
#     def __init__(self, x, y):
#         self.x = x
#         self.y = y
    
#     def __str__(self):
#         return f"P({self.x}, {self.y})"
    
#     def __add__(self, other):
#         new_point = Point(self.x+other.x, self.y+other.y)
#         return new_point

    # def __sub__
    # def __mul__
    # def __div__
    # def __truediv__
    # def __mod__
    


# p1 = Point(1,1)
# p2 = Point(5,5)        

# # print(p1)
# added_point = p1 + p2 # operator overloading

# print(added_point)
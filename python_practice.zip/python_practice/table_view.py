import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.title("Scrollable Table Example")
root.geometry("600x400")

# ---------- Frame for table ----------
table_frame = ttk.Frame(root)
table_frame.pack(fill="both", expand=True, padx=10, pady=10)

# ---------- Scrollbar ----------
scrollbar = ttk.Scrollbar(table_frame, orient="vertical")
scrollbar.pack(side="right", fill="y")

# ---------- Treeview (Table) ----------
columns = ("id", "name", "course", "status")

table = ttk.Treeview(
    table_frame,
    columns=columns,
    show="headings",
    yscrollcommand=scrollbar.set
)

scrollbar.config(command=table.yview)

# ---------- Define headings ----------
table.heading("id", text="ID")
table.heading("name", text="Name")
table.heading("course", text="Course")
table.heading("status", text="Status")

# ---------- Define column width ----------
table.column("id", width=50, anchor="center")
table.column("name", width=150)
table.column("course", width=150)
table.column("status", width=100, anchor="center")

table.pack(fill="both", expand=True)

# ---------- Insert sample data ----------
students = [
    (1, "Amit", "BCA", "Present"),
    (2, "Sita", "BSc", "Absent"),
    (3, "Ram", "BIM", "Present"),
    (4, "Gita", "BCA", "Present"),
]

for student in students:
    table.insert("", "end", values=student)

root.mainloop()

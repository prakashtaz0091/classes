import tkinter as tk

root = tk.Tk()
SCREEN_WIDTH = root.winfo_screenwidth()
SCREEN_HEIGHT = root.winfo_screenheight()
root.title("Grid layout try")
root.geometry(f"{SCREEN_WIDTH}x{SCREEN_HEIGHT}")

BACKGROUND_COLOR = "#333"
HEADER_BG_COLOR = "#666"
BTN_ACTIVE_BG_COLOR = "#333"
BTN_ACTIVE_FG_COLOR = "white"

# Main frame main container
mainframe = tk.Frame(root, bg="lightgreen")
mainframe.pack(fill="both", expand=True)

# grid layout configure in main container
mainframe.rowconfigure(0, weight=1)
mainframe.rowconfigure(1, weight=12)
mainframe.columnconfigure(0, weight=1)
mainframe.columnconfigure(1, weight=8)

# four different frames
frame1 = tk.Frame(mainframe, bg=HEADER_BG_COLOR)
frame2 = tk.Frame(mainframe, bg=HEADER_BG_COLOR)
frame3 = tk.Frame(mainframe, bg=HEADER_BG_COLOR)
main_content_frame = tk.Frame(mainframe, bg=BACKGROUND_COLOR)

# placing frames in grid
frame1.grid(column=0, row=0, sticky="news")
frame2.grid(column=1, row=0, sticky="news")
frame3.grid(column=0, row=1, sticky="news")
main_content_frame.grid(column=1, row=1, sticky="news")

# application name in top left corner
application_name = tk.Label(frame1, text="ABC Pvt. Ltd.", font=("Arial", 24, "bold"))
application_name.pack(fill="both", expand=True)

header_label = tk.Label(
    frame2,
    text="Dashboard >> ",
    font=("Arial", 16, "bold"),
    anchor="w",
    padx=20,
    bg=HEADER_BG_COLOR,
)
header_label.pack(fill="x", ipady=10, expand=True)

sidebar_buttons = {}

def clear_main_content_frame():
    for widget in main_content_frame.winfo_children():
        widget.pack_forget()

def dashboard_btn_click():
    print("Dashboard clicked")
    for widget in frame2.winfo_children():
        widget.destroy()

    header_label = tk.Label(
        frame2,
        text="Dashboard >> ",
        font=("Arial", 16, "bold"),
        anchor="w",
        padx=20,
        bg=HEADER_BG_COLOR,
    )
    header_label.pack(fill="x", ipady=10, expand=True)
    # Get state using cget()
    print("State: ", sidebar_buttons["dashboard_btn"].cget("state"))

    # Set state using config()
    sidebar_buttons["dashboard_btn"].config(state="active")
    dashboard_frame.pack(fill="both", expand=True, padx=10, pady=10)


def courses_btn_click():
    print("Courses clicked")
    for widget in frame2.winfo_children():
        widget.destroy()

    header_label = tk.Label(
        frame2,
        text="Courses >> ",
        font=("Arial", 16, "bold"),
        anchor="w",
        padx=20,
        bg=HEADER_BG_COLOR,
    )
    header_label.pack(fill="x", ipady=10, expand=True)
    
    # destroy main contents
    clear_main_content_frame()


def certificates_btn_click():
    print("Certificates clicked")
    for widget in frame2.winfo_children():
        widget.destroy()

    header_label = tk.Label(
        frame2,
        text="Certificates >> ",
        font=("Arial", 16, "bold"),
        anchor="w",
        padx=20,
        bg=HEADER_BG_COLOR,
    )
    header_label.pack(fill="x", ipady=10, expand=True)
    
    # destroy main contents
    clear_main_content_frame()


def internships_btn_click():
    print("Internships clicked")
    for widget in frame2.winfo_children():
        widget.destroy()

    header_label = tk.Label(
        frame2,
        text="Internships >> ",
        font=("Arial", 16, "bold"),
        anchor="w",
        padx=20,
        bg=HEADER_BG_COLOR,
    )
    header_label.pack(fill="x", ipady=10, expand=True)
    
    # destroy main contents
    clear_main_content_frame()


sidebar_buttons["dashboard_btn"] = tk.Button(
    frame3,
    text="Dashboard",
    command=dashboard_btn_click,
    activebackground=BTN_ACTIVE_BG_COLOR,
    activeforeground=BTN_ACTIVE_FG_COLOR
)
sidebar_buttons["courses_btn"] = tk.Button(
    frame3, text="Courses", command=courses_btn_click, 
    activebackground=BTN_ACTIVE_BG_COLOR,
    activeforeground=BTN_ACTIVE_FG_COLOR
)
sidebar_buttons["certificates_btn"] = tk.Button(
    frame3,
    text="Certificates",
    command=certificates_btn_click,
    activebackground=BTN_ACTIVE_BG_COLOR,
    activeforeground=BTN_ACTIVE_FG_COLOR
)
sidebar_buttons["internships_btn"] = tk.Button(
    frame3,
    text="Internships",
    command=internships_btn_click,
    activebackground=BTN_ACTIVE_BG_COLOR,
    activeforeground=BTN_ACTIVE_FG_COLOR
)

sidebar_buttons["dashboard_btn"].pack(fill="x", padx=10, pady=(20, 5), ipady=10)
sidebar_buttons["courses_btn"].pack(fill="x", padx=10, pady=5, ipady=10)
sidebar_buttons["certificates_btn"].pack(fill="x", padx=10, pady=5, ipady=10)
sidebar_buttons["internships_btn"].pack(fill="x", padx=10, pady=5, ipady=10)


##########----Dashboard-----######
dashboard_frame = tk.Frame(main_content_frame)
dashboard_frame.pack(fill="both", expand=True, padx=10, pady=10)

dashboard_frame.rowconfigure(0, weight=1)
dashboard_frame.rowconfigure(1, weight=3)
dashboard_frame.rowconfigure(2, weight=3)
dashboard_frame.columnconfigure(0, weight=1)
dashboard_frame.columnconfigure(1, weight=1)
dashboard_frame.columnconfigure(2, weight=1)
dashboard_frame.columnconfigure(3, weight=1)

#---------------Stats Cards----------------#
#---------------Stats Cards----------------#
no_of_courses_label = tk.Label(dashboard_frame, font=("Arial", 24, "bold"), text="Courses\n100", bg="green")
no_of_courses_label.grid(row=0, column=0, padx=10, pady=10, sticky="news")

no_of_students_label = tk.Label(dashboard_frame, font=("Arial", 24, "bold"), text="students\n899", bg="yellow")
no_of_students_label.grid(row=0, column=1, padx=10, pady=10, sticky="news")

no_of_certificates_label = tk.Label(dashboard_frame, font=("Arial", 24, "bold"), text="certificates\n8009", bg="lightblue")
no_of_certificates_label.grid(row=0, column=2, padx=10, pady=10, sticky="news")

no_of_instructors_label = tk.Label(dashboard_frame, font=("Arial", 24, "bold"), text="instructors\n67", bg="darkred", fg="white")
no_of_instructors_label.grid(row=0, column=3, padx=10, pady=10, sticky="news")

#---------------Stats Cards End----------------#
#---------------Stats Cards End----------------#


#---------------Main graph----------------#
#---------------Main graph----------------#

main_graph_frame = tk.Frame(dashboard_frame, bg="blue")
main_graph_frame.grid(row=1, column=0, columnspan=2, rowspan=2, sticky="news", padx=10, pady=10)

#---------------Main graph End----------------#
#---------------Main graph End----------------#


#---------------Sub graph 1----------------#
#---------------Sub graph 1----------------#

sub_graph1_frame = tk.Frame(dashboard_frame, bg="yellow")
sub_graph1_frame.grid(row=1, column=2, columnspan=2, sticky="news", padx=10, pady=10)

#---------------Sub graph 1 End----------------#
#---------------Sub graph 1 End----------------#

#---------------Sub graph 2----------------#
#---------------Sub graph 2----------------#

sub_graph1_frame = tk.Frame(dashboard_frame, bg="green")
sub_graph1_frame.grid(row=2, column=2, columnspan=2, sticky="news", padx=10, pady=10)

#---------------Sub graph 2 End----------------#
#---------------Sub graph 2 End----------------#




##########----Dashboard-----######


root.mainloop()

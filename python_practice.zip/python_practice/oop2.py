# Class -> Blueprint, Format, Structure
# Object -> Actual value/instance of a class
# Kunai pani class object banaune process lai hami instantiation vanxam
# __init__ -> Method (simply a function but it's tightly/directly related to a class/object)
# __init__ is also called as constructor, since it helps us during new object creation
# attributes -> they are simply variables, but tied to a class/object
# methods -> they are simply functions, but tied to a class/object
# __del__ -> this is called as destructor, since it is used to delete an object
# self -> it is a reference to the current object


class Student:
    def __init__(self, name, marks):
        self.name = name # public attribute
        # self.marks = marks # public attribute
        # self._marks = marks # protected attribute
        self.__marks = marks # private attribute
        
    
    @property
    def marks(self): # getter
        return f"Marks are : {self.__marks}" 
    
    
    @marks.setter
    def marks(self, marks): # setter
        # if marks is not the object of int or float class
        # or simply, if marks value is not int or float
        if not isinstance(marks, (int, float)):
            return
        
        if marks < 0 or marks > 100:
            return
            # raise Exception("Marks should be between 0 to 100")
            
        self.__marks.append(marks)
    
    

    def total_marks(self):
        # print("Total Marks = ", sum(self.marks))
        # print("Total Marks = ", sum(self._marks))
        print("Total Marks = ", sum(self.__marks))

    def add_marks(self, new_marks):  # setter
        # self.marks.append(new_marks)
        # self._marks.append(new_marks)
        self.__marks.append(new_marks)

    # def __del__(self):
    #     print("Object deleted ", self.name)


ram = Student("Ram", [45, 56, 78])
# hari = Student("Hari", [50, 46, 70])
# shyam = Student("Shyam", [34, 67, 76])


# ram.total_marks()

# print(ram.name, ram.marks)


####################################
# To update a value of an attribute
####################################
# print(ram.name)

# ram.name = "Ram Thapa"

# print(ram.name)


####################################
# To update a value of an attribute
####################################
# print(ram._marks)
# print(ram.__marks)
# print(ram._Student__marks)

# ram.marks = 50
# ram._marks = 50
# ram._Student__marks = 50

# ram.add_marks(50)

# print(ram._marks)
# print(ram.__marks)

# ram.__marks = 50
# print(ram.__marks)
# print(ram._Student__marks)

# ram.marks = 50
# ram.marks = -50
# ram.marks = "50"
# ram.marks = 50
# print(ram.marks)
import tkinter as tk
from tkinter import messagebox

USERNAME = "admin"
PASSWORD = "admin"

WIDTH = 500
HEIGHT = 600
root = tk.Tk()
root.title("Library System")
root.geometry(f"{WIDTH}x{HEIGHT}")
root.resizable(False, False)

mainframe = tk.Frame(root, bg="lightblue")
mainframe.pack(fill="both", expand=True)

heading_label = tk.Label(
    mainframe,
    bg="lightblue", 
    fg="blue", 
    text="LOGIN", 
    font=("Arial", 24, "bold"),
    )
heading_label.pack(pady=20)


username_label = tk.Label(
    mainframe,
    bg="lightblue",
    text="Username",
    font=("Arial", 18, "bold"),
    )
username_label.pack(pady=10)

username_entry = tk.Entry(
    mainframe,
    bg="lightgray",
    font=("Arial", 16),
    width=WIDTH
)
username_entry.pack(padx=20, ipady=10)



password_label = tk.Label(
    mainframe,
    bg="lightblue",
    text="Password",
    font=("Arial", 18, "bold"),
    )
password_label.pack(pady=(30, 10))

password_entry = tk.Entry(
    mainframe,
    bg="lightgray",
    font=("Arial", 16),
    width=WIDTH,
    show="*"
)
password_entry.pack(padx=20, ipady=10)



def handle_login():
    username = username_entry.get()
    password = password_entry.get()
    
    if username == USERNAME and password == PASSWORD:
        print("Login success")
        messagebox.showinfo("Success", "Login Successful", detail="Now you can access the system")
        username_entry.delete(0, tk.END)
    else:
        print("Invalid credentials")
        messagebox.showerror("Login failed", "Invalid credentials", detail="Please contact the administrator if you forgot credentials")
        password_entry.delete(0, tk.END)



login_btn = tk.Button(
    mainframe,
    bg="lightgray",
    text="Login",
    font=("Arial", 16, "bold"),
    width=WIDTH,
    command=handle_login
)
login_btn.pack(padx=20,pady=40, ipady=10)


signup_label = tk.Label(
    mainframe,
    bg="lightblue",
    text="Sign up",
    font=("Arial", 18, "italic"),
    )
signup_label.pack()



root.mainloop()
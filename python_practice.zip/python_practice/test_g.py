import tkinter as tk

root = tk.Tk()

# Full screen
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
root.geometry(f"{screen_width}x{screen_height}")
root.title("Sidebar Layout App")

# ---- GRID CONFIGURATION ----
root.columnconfigure(0, weight=1)   # Sidebar
root.columnconfigure(1, weight=4)   # Main content

root.rowconfigure(0, weight=1)      # Header
root.rowconfigure(1, weight=8)      # Main area

# ---- SIDEBAR ----
sidebar_frame = tk.Frame(root, bg="lightblue", width=150)
sidebar_frame.grid(row=0, column=0, rowspan=2, sticky="nsew")

# ---- HEADER ----
header_frame = tk.Frame(root, bg="skyblue", height=40)
header_frame.grid(row=0, column=1, sticky="nsew")

header_label = tk.Label(header_frame, text="My App", font=("Arial", 16), bg="skyblue")
header_label.pack(padx=10, pady=5)

# ---- MAIN CONTENT ----
main_frame = tk.Frame(root, bg="lightgray")
main_frame.grid(row=1, column=1, sticky="nsew")

# --------------------------------
# MAIN CONTENT SWITCHING LOGIC
# --------------------------------
def clear_main():
    """Remove all widgets from main_frame"""
    for widget in main_frame.winfo_children():
        widget.destroy()

def show_home():
    clear_main()
    tk.Label(
        main_frame,
        text="🏠 Home Page",
        font=("Arial", 20),
        bg="lightgray"
    ).pack(pady=40)

def show_settings():
    clear_main()
    tk.Label(
        main_frame,
        text="⚙ Settings Page",
        font=("Arial", 20),
        bg="lightgray"
    ).pack(pady=40)

def show_about():
    clear_main()
    tk.Label(
        main_frame,
        text="ℹ About Page",
        font=("Arial", 20),
        bg="lightgray"
    ).pack(pady=40)

# ---- SIDEBAR CONTENT ----
tk.Label(
    sidebar_frame,
    text="MENU",
    bg="lightblue",
    font=("Arial", 14, "bold")
).pack(pady=(10, 20))

tk.Button(sidebar_frame, text="Home", command=show_home).pack(fill="x", padx=10, pady=5)
tk.Button(sidebar_frame, text="Settings", command=show_settings).pack(fill="x", padx=10, pady=5)
tk.Button(sidebar_frame, text="About", command=show_about).pack(fill="x", padx=10, pady=5)

# Load default page
show_home()

root.mainloop()

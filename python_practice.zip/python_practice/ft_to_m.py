import tkinter as tk
from tkinter import ttk



def conv_to_meter():
    try:
        km_value = float(km_entry.get())
    except ValueError:
        result_var.set("Please enter correct value (numbers)")
    else:
        meter_result = km_value*1000
        result_var.set(f"Result: {meter_result} meters")

root = tk.Tk()
root.title("Feet to Meters Caculator")
root.geometry("500x400")
root.resizable(False, False)

# frame = tk.Frame(root, bg="lightblue")
frame = tk.Frame(root, bg="#0f0") # RGB, 0-f
frame.pack(fill="both", expand=True)

# Add a label inside the frame
welcome_text = tk.Label(frame, text="Welcome to Kilometer to meter converter", bg="lightblue", font=("Arial", 16))
welcome_text.pack(pady=20)

km_entry = tk.Entry(frame)
km_entry.pack(pady=20)

result_var = tk.StringVar()
result_var.set("Result: ")


result_label = tk.Label(frame, textvariable=result_var, bg="lightblue", font=("Arial", 16))
result_label.pack(pady=20)

calc_btn = tk.Button(frame, text="Convert", command=conv_to_meter)
calc_btn.pack()

root.mainloop()
import pygame
import random

SCREEN_WIDTH = 720
SCREEN_HEIGHT = 980

# pygame setup
pygame.init()

# initialize mixer
pygame.mixer.init()

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()
running = True

enemy_img = pygame.image.load("./assets/images/enemy.png").convert_alpha()
scale_factor = 0.07
scaled_width = enemy_img.get_width()*scale_factor
scaled_height = enemy_img.get_height()*scale_factor
enemy_img = pygame.transform.scale(enemy_img, (scaled_width, scaled_height))

background = pygame.image.load("./assets/images/stars.jpg").convert()
background = pygame.transform.scale(background, (SCREEN_WIDTH, SCREEN_HEIGHT))


spaceship = pygame.image.load("./assets/images/ship.png").convert_alpha()
spaceship_sf = 0.2
spaceship_sw = spaceship.get_width()*spaceship_sf
spaceship_sh = spaceship.get_height()*spaceship_sf
spaceship = pygame.transform.scale(spaceship, (spaceship_sw, spaceship_sh))
ship_x = SCREEN_WIDTH/2
ship_y = SCREEN_HEIGHT-100
ship_speed = 5


# background music
# Sounds
pygame.mixer.music.load("./assets/sounds/background.wav")
pygame.mixer.music.set_volume(0.2)
pygame.mixer.music.play(-1)


class Enemy:
    enemies = []
    
    def __init__(self, speed=3):
        self.x = random.randint(20, SCREEN_WIDTH-40)
        self.y = -random.randint(20, 40)
        self.speed = speed
        
        Enemy.enemies.append(self)
        
    def display(self):
        screen.blit(enemy_img, (self.x, self.y))
  
    def move(self):
        # self.y = self.y + self.speed
        # if self.y < 600:
        if self.y < SCREEN_HEIGHT:
            self.y += self.speed
        else:
            self.y = -random.randint(20, 40)
            self.x = random.randint(20, SCREEN_WIDTH-40)
    
    @staticmethod
    def generate_enemies(n):
        for _ in range(n):
            Enemy(speed=random.random()+3)


Enemy.generate_enemies(10)

while running:
    # poll for events
    # pygame.QUIT event means the user clicked X to close your window
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and ship_x > 0:
        ship_x -= ship_speed
    if keys[pygame.K_RIGHT] and ship_x < SCREEN_WIDTH-40:
        ship_x += ship_speed
    if keys[pygame.K_UP] and ship_y > 0:
        ship_y -= ship_speed
    if keys[pygame.K_DOWN] and ship_y < SCREEN_HEIGHT-40:
        ship_y += ship_speed

    # fill the screen with a background
    screen.blit(background, (0, 0))
    
    for enemy in Enemy.enemies:
        enemy.display()
        enemy.move()
        
    screen.blit(spaceship, (ship_x, ship_y))
   
            
    # flip() the display to put your work on screen
    pygame.display.flip()

    clock.tick(60)  # limits FPS to 60

pygame.quit()
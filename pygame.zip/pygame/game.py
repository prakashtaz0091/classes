import pygame
import math

SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720

# pygame setup
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()
running = True


class Circle:
    def __init__(self, radius, width, x, y, speed=10, direction="right", color="white"):
        self.radius = radius
        self.width = width
        self.x = x
        self.y = y
        self.speed = speed
        self.direction = direction
        self.color = color
        
    def display(self, screen):
        pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius, self.width)
        
    def move(self):
        if self.direction == "right" and self.x < SCREEN_WIDTH-self.radius:
            self.x = self.x + self.speed
            if self.x >= SCREEN_WIDTH-self.radius:
                self.direction = "left"
        elif self.direction == "left" and self.x > self.radius:
            self.x = self.x - self.speed
            if self.x <= self.radius:
                self.direction = "right"

    def circular_move(self, radius, speed, x, y):
        # Initialize angle attribute if it doesn't exist
        if not hasattr(self, 'angle'):
            self.angle = 0
            self.center_x = x
            self.center_y = y
        
        # Increment the angle based on speed
        self.angle += speed
        
        # Calculate new position on circular path
        self.x = self.center_x + radius * math.cos(math.radians(self.angle))
        self.y = self.center_y + radius * math.sin(math.radians(self.angle))


circle1 = Circle(50,5, 50, 100, 8)
circle2 = Circle(radius=40,
                 width=4,
                 color="green",
                 speed=8,
                 x=40,
                 y=300
                 )
circle3 = Circle(60,5, 60, 600, 12, color="blue")


while running:
    # poll for events
    # pygame.QUIT event means the user clicked X to close your window
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # fill the screen with a color to wipe away anything from last frame
    screen.fill("black")

    # RENDER YOUR GAME HERE
    circle1.display(screen)
    # circle1.circular_move(60, 10, 500, 500)
    circle2.display(screen)
    circle3.display(screen)

    circle1.move()
    circle2.move()
    circle3.move()
            

        
    # flip() the display to put your work on screen
    pygame.display.flip()

    clock.tick(60)  # limits FPS to 60

pygame.quit()
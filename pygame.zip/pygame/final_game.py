import pygame
import random

SCREEN_WIDTH = 720
SCREEN_HEIGHT = 980

# pygame setup
pygame.init()

# initialize mixer
pygame.mixer.init()

# font init
font = pygame.font.Font(None, 72)
score_font = pygame.font.Font(None, 48)  # Font for score display

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()
running = True

enemy_img = pygame.image.load("./assets/images/enemy.png").convert_alpha()
scale_factor = 0.07
scaled_width = enemy_img.get_width() * scale_factor
scaled_height = enemy_img.get_height() * scale_factor
enemy_img = pygame.transform.scale(enemy_img, (scaled_width, scaled_height))
enemy_mask = pygame.mask.from_surface(enemy_img)

background = pygame.image.load("./assets/images/stars.jpg").convert()
background = pygame.transform.scale(background, (SCREEN_WIDTH, SCREEN_HEIGHT))

spaceship = pygame.image.load("./assets/images/ship.png").convert_alpha()
spaceship_sf = 0.2
spaceship_sw = spaceship.get_width() * spaceship_sf
spaceship_sh = spaceship.get_height() * spaceship_sf
spaceship = pygame.transform.scale(spaceship, (spaceship_sw, spaceship_sh))
spaceship_mask = pygame.mask.from_surface(spaceship)
ship_x = SCREEN_WIDTH / 2
ship_y = SCREEN_HEIGHT - 100
ship_speed = 5

bullet_img = pygame.image.load("./assets/images/bullet.png").convert_alpha()
bullet_sf = 0.1
bullet_sw = bullet_img.get_width() * bullet_sf
bullet_sh = bullet_img.get_height() * bullet_sf
bullet_img = pygame.transform.scale(bullet_img, (bullet_sw, bullet_sh))
bullet_mask = pygame.mask.from_surface(bullet_img)

# background music
# Sounds
pygame.mixer.music.load("./assets/sounds/background.wav")
pygame.mixer.music.set_volume(0.2)
pygame.mixer.music.play(-1)

shoot_sound = pygame.mixer.Sound("./assets/sounds/fire.mp3")
shoot_sound.set_volume(0.2)

explosion_sound = pygame.mixer.Sound("./assets/sounds/explosion.wav")
explosion_sound.set_volume(0.2)
game_over_sound = pygame.mixer.Sound("./assets/sounds/game_over.wav")
game_over_sound.set_volume(0.2)

score = 0
score_point = 10


class Enemy:
    enemies = []

    def __init__(self, speed=3):
        self.x = random.randint(20, SCREEN_WIDTH - 40)
        self.y = -random.randint(20, 40)
        self.speed = speed

        Enemy.enemies.append(self)

    def display(self):
        screen.blit(enemy_img, (self.x, self.y))

    def move(self):
        if self.y < SCREEN_HEIGHT:
            self.y += self.speed
        else:
            self.y = -random.randint(20, 40)
            self.x = random.randint(20, SCREEN_WIDTH - 40)

    @staticmethod
    def generate_enemies(n):
        for _ in range(n):
            Enemy(speed=random.random() + 3)

    def __del__(self):
        global score
        score += score_point
        explosion_sound.play()


class Bullet:
    speed = 15
    all_bullets = []
    last_shottime = 0
    fire_cooldown = 200

    def __init__(self):
        self.x = ship_x + spaceship.get_width() / 2 - bullet_img.get_width() / 2
        self.y = ship_y

        Bullet.all_bullets.append(self)
        shoot_sound.play()

    def move(self):
        self.y -= Bullet.speed

    @staticmethod
    def move_all_bullets():
        # Remove bullets that are off screen using list comprehension
        Bullet.all_bullets = [b for b in Bullet.all_bullets if b.y > -10]

        # Move remaining bullets
        for bullet in Bullet.all_bullets:
            bullet.move()

    @staticmethod
    def show_all_bullets():
        bullets_to_remove = []
        enemies_to_remove = []

        # Check collisions
        for bullet in Bullet.all_bullets:
            if bullet in bullets_to_remove:
                continue

            for enemy in Enemy.enemies:
                if enemy in enemies_to_remove:
                    continue

                offset = (bullet.x - enemy.x, bullet.y - enemy.y)

                if enemy_mask.overlap(bullet_mask, offset):  # if bullet strikes enemy
                    bullets_to_remove.append(bullet)
                    enemies_to_remove.append(enemy)
                    break  # Bullet can only hit one enemy

        # Remove hit bullets and enemies
        for bullet in bullets_to_remove:
            if bullet in Bullet.all_bullets:
                Bullet.all_bullets.remove(bullet)

        for enemy in enemies_to_remove:
            if enemy in Enemy.enemies:
                Enemy.enemies.remove(enemy)
                Enemy()  # Spawn new enemy

        # Draw remaining bullets
        for bullet in Bullet.all_bullets:
            screen.blit(bullet_img, (bullet.x, bullet.y))


Enemy.generate_enemies(10)

game_over = False
game_over_text = font.render("Game Over !!!", True, "red")
game_over_text_rect = game_over_text.get_rect(
    center=(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2)
)

while running:
    # poll for events
    # pygame.QUIT event means the user clicked X to close your window
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if not game_over:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and ship_x > 0:
            ship_x -= ship_speed
        if keys[pygame.K_RIGHT] and ship_x < SCREEN_WIDTH - spaceship_sw:
            ship_x += ship_speed
        if keys[pygame.K_UP] and ship_y > 0:
            ship_y -= ship_speed
        if keys[pygame.K_DOWN] and ship_y < SCREEN_HEIGHT - spaceship_sh:
            ship_y += ship_speed

        current_time = pygame.time.get_ticks()
        if (
            keys[pygame.K_SPACE]
            and current_time - Bullet.last_shottime >= Bullet.fire_cooldown
        ):
            Bullet()
            Bullet.last_shottime = current_time

    # fill the screen with a background
    screen.blit(background, (0, 0))

    spaceship_rect = spaceship.get_rect(topleft=(ship_x, ship_y))

    for enemy in Enemy.enemies:
        enemy.display()
        if not game_over:
            enemy.move()

            offset = (enemy.x - ship_x, enemy.y - ship_y)
            if spaceship_mask.overlap(enemy_mask, offset):
                game_over = True
                game_over_sound.play()

    Bullet.show_all_bullets()
    Bullet.move_all_bullets()
    screen.blit(spaceship, (ship_x, ship_y))

    # show scores
    score_text = font.render(f"SCORE # {score}", True, "white")
    score_text_rect = score_text.get_rect(center=(SCREEN_WIDTH - 200, 30))
    screen.blit(score_text, score_text_rect)

    if game_over:
        screen.blit(game_over_text, game_over_text_rect)

    # flip() the display to put your work on screen
    pygame.display.flip()

    clock.tick(60)  # limits FPS to 60

pygame.quit()

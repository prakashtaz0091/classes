# """
# 1. Load students data
# 2. Open the camera
# 3. Check if faces are available in the captured frame
# 4. if face detected, compare the face with registered students face

# """


import pickle
import cv2
import face_recognition
import datetime
import csv

students = None

# load all the students data
with open("students.pkl", "rb") as file:
    students = pickle.load(file)


students_names = [student["name"] for student in students]
students_encodings = [student["face"] for student in students]

present_students = set()
present_students_list = []

# print(students_encodings)


# open camera
cap = cv2.VideoCapture(0)

print("Capturing face... Look at the camera!")


while True:
    ret, frame = cap.read()    
    if not ret:
        print("Failed to capture image")
        break

    # Detect face locations
    face_locations = face_recognition.face_locations(frame)
    # Draw green rectangle around each detected face
    for top, right, bottom, left in face_locations:
        # Draw a rectangle around the face
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)

    # Show the frame to the user
    cv2.imshow("Face Capture", frame)

    # check if anyone appears infront of camera
    if len(face_locations) > 0:
        face_encodings = face_recognition.face_encodings(frame)
        comp_result = None
        for face in face_encodings:
            comp_result = face_recognition.compare_faces(students_encodings, face)
            
            if True in comp_result:
                matched_index = comp_result.index(True)
                now = datetime.datetime.now()
                student_name = students_names[matched_index]
                
                if student_name not in present_students:
                    present_students.add(student_name)
                    present_students_list.append((student_name, now))
                    print(matched_index, student_name, "present", now)


    # Press 'q' to save the face
    if cv2.waitKey(1) & 0xFF == ord("q"):
        print("turning off attendance system")
        break


cap.release()
cv2.destroyAllWindows()

file_name = f"attendance_data/Attendane-{datetime.datetime.now().strftime("%Y-%m-%d")}.csv"
with open(file_name, "w") as file:
    csv_writer = csv.writer(file)
    csv_writer.writerows(present_students_list) 
    

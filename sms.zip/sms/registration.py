import cv2
import face_recognition
import pickle

students = []


def capture_face():
    # Step 1: Capture image from webcam
    cap = cv2.VideoCapture(0)

    print("Capturing face... Look at the camera!")

    student_face_encoding = None

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to capture image")
            break

        # Detect face locations
        face_locations = face_recognition.face_locations(frame)
        face_encodings = face_recognition.face_encodings(frame)
        
        # Draw green rectangle around each detected face
        for top, right, bottom, left in face_locations:
            # Draw a rectangle around the face
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)

        # Show the frame to the user
        cv2.imshow("Face Capture", frame)

        # Press 's' to save the face
        if cv2.waitKey(1) & 0xFF == ord("s"):
            if len(face_encodings) > 1:
                print("Multiple face detected, Ensure only one student is in the frame")
            elif len(face_encodings) == 0:
                print("No face detected")
            else:       
                try:
                    student_face_encoding = face_encodings[0]   
                except Exception:
                    student_face_encoding = None
                
                break

    cap.release()
    cv2.destroyAllWindows()
    
    return student_face_encoding


while True:
    print("""
          1. New student
          2. Show students
          3. Exit
          """)
    
    user_choice = input("Enter your choice: ")
    
    if user_choice == "1":
        # open camera to capture student's face
        # capture face and detect and then extract face encoding
        face_encoding = capture_face()
        
        if face_encoding is not None:
            student_name = input("Enter student name: ")
            new_student = {
                'name': student_name,
                'face': face_encoding 
            }
            students.append(new_student)
            
    elif user_choice == "2":
        print(students)
    elif user_choice == "3":
        print("Saving data in pickle file")
        with open("students.pkl", "wb") as file:
            pickle.dump(students, file)
        print("Data saved...")
        print("Exiting...")
        break
    else:
        print("Please enter valid input")
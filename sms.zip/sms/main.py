import tkinter as tk
from tkinter import ttk, messagebox
import csv
import os
import cv2
import face_recognition


class StudentManagementSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Attendance Management")
        self.root.geometry("900x600")
        self.root.configure(bg="#f0f0f0")
        
        # CSV file path
        self.csv_file = "students.csv"
        self.initialize_csv()
        
        # Create main UI
        self.create_widgets()
        self.load_students()
    
    def initialize_csv(self):
        """Initialize CSV file with headers and dummy data if it doesn't exist"""
        if not os.path.exists(self.csv_file):
            with open(self.csv_file, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(['ID', 'Name', 'Address', 'Class', 'RollNo'])
                # Add dummy data
                dummy_data = [
                    ['1', 'John Smith', '123 Main St, New York', '10th Grade', '101'],
                    ['2', 'Emma Johnson', '456 Oak Ave, Boston', '9th Grade', '102'],
                    ['3', 'Michael Brown', '789 Pine Rd, Chicago', '10th Grade', '103'],
                    ['4', 'Sophia Davis', '321 Elm St, Seattle', '11th Grade', '104'],
                    ['5', 'William Wilson', '654 Maple Dr, Denver', '9th Grade', '105'],
                    ['6', 'Olivia Martinez', '987 Cedar Ln, Miami', '10th Grade', '106'],
                    ['7', 'James Anderson', '147 Birch St, Austin', '11th Grade', '107'],
                    ['8', 'Ava Taylor', '258 Spruce Ave, Portland', '9th Grade', '108'],
                ]
                writer.writerows(dummy_data)
    
    def create_widgets(self):
        """Create all UI widgets"""
        # Title
        title_frame = tk.Frame(self.root, bg="#2c3e50", height=60)
        title_frame.pack(fill=tk.X)
        title_frame.pack_propagate(False)
        
        title_label = tk.Label(title_frame, text="View Add Attendance", 
                              font=("Arial", 18, "bold"), bg="#2c3e50", fg="white")
        title_label.pack(pady=15)
        
        # Search Frame
        search_frame = tk.Frame(self.root, bg="#f0f0f0", height=70)
        search_frame.pack(fill=tk.X, padx=20, pady=10)
        
        self.search_var = tk.StringVar()
        search_entry = tk.Entry(search_frame, textvariable=self.search_var, 
                               font=("Arial", 14), width=40)
        search_entry.pack(side=tk.LEFT, padx=5, ipady=8)
        
        search_btn = tk.Button(search_frame, text="Search", font=("Arial", 12, "bold"),
                              bg="#3498db", fg="white", padx=20, pady=8,
                              command=self.search_student, cursor="hand2")
        search_btn.pack(side=tk.LEFT, padx=5)
        
        clear_btn = tk.Button(search_frame, text="Clear", font=("Arial", 12),
                             bg="#95a5a6", fg="white", padx=15, pady=8,
                             command=self.clear_search, cursor="hand2")
        clear_btn.pack(side=tk.LEFT, padx=5)
        
        add_btn = tk.Button(search_frame, text="+ Add Student", font=("Arial", 12, "bold"),
                           bg="#27ae60", fg="white", padx=20, pady=8,
                           command=self.add_student_window, cursor="hand2")
        add_btn.pack(side=tk.RIGHT, padx=5)
        
        # Table Frame
        table_frame = tk.Frame(self.root, bg="#f0f0f0")
        table_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(table_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Treeview (Table)
        columns = ('ID', 'Name', 'Address', 'Class', 'RollNo')
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings",
                                yscrollcommand=scrollbar.set, height=15)
        
        # Configure scrollbar
        scrollbar.config(command=self.tree.yview)
        
        # Define column headings
        self.tree.heading('ID', text='ID')
        self.tree.heading('Name', text='Name')
        self.tree.heading('Address', text='Address')
        self.tree.heading('Class', text='Class')
        self.tree.heading('RollNo', text='RollNo')
        
        # Define column widths
        self.tree.column('ID', width=50, anchor=tk.CENTER)
        self.tree.column('Name', width=150, anchor=tk.W)
        self.tree.column('Address', width=250, anchor=tk.W)
        self.tree.column('Class', width=100, anchor=tk.CENTER)
        self.tree.column('RollNo', width=80, anchor=tk.CENTER)
        
        # Style configuration
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('Treeview', font=('Arial', 10), rowheight=30)
        style.configure('Treeview.Heading', font=('Arial', 11, 'bold'), 
                       background='#34495e', foreground='white')
        style.map('Treeview', background=[('selected', "#062236")])
        
        self.tree.pack(fill=tk.BOTH, expand=True)
        
        # Bind double-click to view details
        self.tree.bind('<Double-1>', self.view_student_details)
        
        # Bind right-click for context menu
        self.tree.bind('<Button-3>', self.show_context_menu)
    
    def load_students(self):
        """Load students from CSV file into the table"""
        # Clear existing items
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Read from CSV
        try:
            with open(self.csv_file, 'r') as file:
                reader = csv.reader(file)
                next(reader)  # Skip header
                for row in reader:
                    if row:  # Check if row is not empty
                        self.tree.insert('', tk.END, values=row)
        except Exception as e:
            messagebox.showerror("Error", f"Error loading students: {str(e)}")
    
    def search_student(self):
        """Search students by name"""
        search_term = self.search_var.get().lower()
        
        if not search_term:
            self.load_students()
            return
        
        # Clear existing items
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Search in CSV
        try:
            with open(self.csv_file, 'r') as file:
                reader = csv.reader(file)
                next(reader)  # Skip header
                found = False
                for row in reader:
                    if row and search_term in row[1].lower():  # Search in name field
                        self.tree.insert('', tk.END, values=row + ['✏️  ✖️'])
                        found = True
                
                if not found:
                    messagebox.showinfo("Search Result", "No students found!")
        except Exception as e:
            messagebox.showerror("Error", f"Error searching: {str(e)}")
    
    def clear_search(self):
        """Clear search and reload all students"""
        self.search_var.set('')
        self.load_students()
    
    def add_student_window(self):
        """Open window to add new student"""
        add_window = tk.Toplevel(self.root)
        add_window.title("Add New Student")
        add_window.geometry("400x350")
        add_window.configure(bg="#ecf0f1")
        add_window.resizable(False, False)
        
        # Center the window
        add_window.transient(self.root)
        add_window.grab_set()
        
        # Title
        title = tk.Label(add_window, text="Add New Student", 
                        font=("Arial", 16, "bold"), bg="#ecf0f1")
        title.pack(pady=15)
        
        # Form frame
        form_frame = tk.Frame(add_window, bg="#ecf0f1")
        form_frame.pack(padx=30, pady=10, fill=tk.BOTH, expand=True)
        
        # Name
        tk.Label(form_frame, text="Name:", font=("Arial", 11), bg="#ecf0f1").grid(
            row=0, column=0, sticky=tk.W, pady=8)
        name_entry = tk.Entry(form_frame, font=("Arial", 11), width=25)
        name_entry.grid(row=0, column=1, pady=8, padx=10)
        
        # Address
        tk.Label(form_frame, text="Address:", font=("Arial", 11), bg="#ecf0f1").grid(
            row=1, column=0, sticky=tk.W, pady=8)
        address_entry = tk.Entry(form_frame, font=("Arial", 11), width=25)
        address_entry.grid(row=1, column=1, pady=8, padx=10)
        
        # Class
        tk.Label(form_frame, text="Class:", font=("Arial", 11), bg="#ecf0f1").grid(
            row=2, column=0, sticky=tk.W, pady=8)
        class_entry = tk.Entry(form_frame, font=("Arial", 11), width=25)
        class_entry.grid(row=2, column=1, pady=8, padx=10)
        
        # Roll No
        tk.Label(form_frame, text="Roll No:", font=("Arial", 11), bg="#ecf0f1").grid(
            row=3, column=0, sticky=tk.W, pady=8)
        roll_entry = tk.Entry(form_frame, font=("Arial", 11), width=25)
        roll_entry.grid(row=3, column=1, pady=8, padx=10)
        
        # Buttons
        btn_frame = tk.Frame(add_window, bg="#ecf0f1")
        btn_frame.pack(pady=15)
        
        def save_student():
            name = name_entry.get().strip()
            address = address_entry.get().strip()
            class_name = class_entry.get().strip()
            roll_no = roll_entry.get().strip()
            
            if not all([name, address, class_name, roll_no]):
                messagebox.showwarning("Input Error", "All fields are required!")
                return
            
            # Generate new ID
            new_id = self.get_next_id()
            
            # Save to CSV
            try:
                with open(self.csv_file, 'a', newline='') as file:
                    writer = csv.writer(file)
                    writer.writerow([new_id, name, address, class_name, roll_no])
                
                messagebox.showinfo("Success", "Student added successfully!")
                self.load_students()
                add_window.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Error saving student: {str(e)}")
        
        save_btn = tk.Button(btn_frame, text="Save", font=("Arial", 11, "bold"),
                            bg="#27ae60", fg="white", padx=25, pady=8,
                            command=save_student, cursor="hand2")
        save_btn.pack(side=tk.LEFT, padx=5)
        
        cancel_btn = tk.Button(btn_frame, text="Cancel", font=("Arial", 11),
                              bg="#e74c3c", fg="white", padx=20, pady=8,
                              command=add_window.destroy, cursor="hand2")
        cancel_btn.pack(side=tk.LEFT, padx=5)
    
    def get_next_id(self):
        """Get the next available ID"""
        max_id = 0
        try:
            with open(self.csv_file, 'r') as file:
                reader = csv.reader(file)
                next(reader)  # Skip header
                for row in reader:
                    if row:
                        max_id = max(max_id, int(row[0]))
        except:
            pass
        return str(max_id + 1)
    
    def view_student_details(self, event):
        """View student details on double-click"""
        selection = self.tree.selection()
        if not selection:
            return
        
        item = self.tree.item(selection[0])
        values = item['values']
        
        details = f"""
Student Details:

ID: {values[0]}
Name: {values[1]}
Address: {values[2]}
Class: {values[3]}
Roll No: {values[4]}
        """
        messagebox.showinfo("Student Details", details)
    
    def show_context_menu(self, event):
        """Show context menu on right-click"""
        selection = self.tree.selection()
        if not selection:
            return
        
        # Create context menu
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="✏️ Edit", command=self.edit_student)
        menu.add_command(label="👁️ View Details", command=lambda: self.view_student_details(None))
        menu.add_command(label="Update face", command=self.update_face)
        menu.add_separator()
        menu.add_command(label="🗑️ Delete", command=self.delete_student)
        
        menu.post(event.x_root, event.y_root)
    
    def edit_student(self):
        """Edit selected student"""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Selection Error", "Please select a student to edit!")
            return
        
        item = self.tree.item(selection[0])
        values = item['values']
        student_id = values[0]
        
        # Create edit window
        edit_window = tk.Toplevel(self.root)
        edit_window.title("Edit Student")
        edit_window.geometry("400x350")
        edit_window.configure(bg="#ecf0f1")
        edit_window.resizable(False, False)
        
        # Make the edit window transient on the root window
        # This means that the edit window will always be on top of the root window
        edit_window.transient(self.root)
        
        # Grab the focus of the edit window and make it the topmost window
        edit_window.grab_set()
        
        # Title
        title = tk.Label(edit_window, text="Edit Student", 
                        font=("Arial", 16, "bold"), bg="#ecf0f1")
        title.pack(pady=15)
        
        # Form frame
        form_frame = tk.Frame(edit_window, bg="#ecf0f1")
        form_frame.pack(padx=30, pady=10, fill=tk.BOTH, expand=True)
        
        # Name
        tk.Label(form_frame, text="Name:", font=("Arial", 11), bg="#ecf0f1").grid(
            row=0, column=0, sticky=tk.W, pady=8)
        name_entry = tk.Entry(form_frame, font=("Arial", 11), width=25)
        name_entry.insert(0, values[1])
        name_entry.grid(row=0, column=1, pady=8, padx=10)
        
        # Address
        tk.Label(form_frame, text="Address:", font=("Arial", 11), bg="#ecf0f1").grid(
            row=1, column=0, sticky=tk.W, pady=8)
        address_entry = tk.Entry(form_frame, font=("Arial", 11), width=25)
        address_entry.insert(0, values[2])
        address_entry.grid(row=1, column=1, pady=8, padx=10)
        
        # Class
        tk.Label(form_frame, text="Class:", font=("Arial", 11), bg="#ecf0f1").grid(
            row=2, column=0, sticky=tk.W, pady=8)
        class_entry = tk.Entry(form_frame, font=("Arial", 11), width=25)
        class_entry.insert(0, values[3])
        class_entry.grid(row=2, column=1, pady=8, padx=10)
        
        # Roll No
        tk.Label(form_frame, text="Roll No:", font=("Arial", 11), bg="#ecf0f1").grid(
            row=3, column=0, sticky=tk.W, pady=8)
        roll_entry = tk.Entry(form_frame, font=("Arial", 11), width=25)
        roll_entry.insert(0, values[4])
        roll_entry.grid(row=3, column=1, pady=8, padx=10)
        
        # Buttons
        btn_frame = tk.Frame(edit_window, bg="#ecf0f1")
        btn_frame.pack(pady=15)
        
        def update_student():
            name = name_entry.get().strip()
            address = address_entry.get().strip()
            class_name = class_entry.get().strip()
            roll_no = roll_entry.get().strip()
            if not all([name, address, class_name, roll_no]):
                messagebox.showwarning("Input Error", "All fields are required!")
                return
            
            # Update CSV
            try:
                rows = []
                with open(self.csv_file, 'r') as file:
                    reader = csv.reader(file)
                    header = next(reader)
                    rows.append(header)
                    for row in reader:
                        if row and str(row[0]) == str(student_id):
                            rows.append([student_id, name, address, class_name, roll_no])
                        else:
                            rows.append(row)
                                
                with open(self.csv_file, 'w', newline='') as file:
                    writer = csv.writer(file)
                    writer.writerows(rows)
                
                messagebox.showinfo("Success", "Student updated successfully!")
                self.load_students()
                edit_window.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Error updating student: {str(e)}")
        
        save_btn = tk.Button(btn_frame, text="Update", font=("Arial", 11, "bold"),
                            bg="#3498db", fg="white", padx=25, pady=8,
                            command=update_student, cursor="hand2")
        save_btn.pack(side=tk.LEFT, padx=5)
        
        cancel_btn = tk.Button(btn_frame, text="Cancel", font=("Arial", 11),
                              bg="#e74c3c", fg="white", padx=20, pady=8,
                              command=edit_window.destroy, cursor="hand2")
        cancel_btn.pack(side=tk.LEFT, padx=5)
    
    def delete_student(self):
        """Delete selected student with confirmation"""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Selection Error", "Please select a student to delete!")
            return
        
        item = self.tree.item(selection[0])
        values = item['values']
        student_id = values[0]
        student_name = values[1]
        
        # Confirmation dialog
        confirm = messagebox.askyesno("Confirm Delete", 
            f"Are you sure you want to delete:\n\n{student_name} (ID: {student_id})?",
            icon='warning')
        
        if not confirm:
            return
        
        # Delete from CSV
        try:
            rows = []
            with open(self.csv_file, 'r') as file:
                reader = csv.reader(file)
                header = next(reader)
                rows.append(header)
                for row in reader:
                    if row and str(row[0]) != str(student_id):
                        rows.append(row)
            
            with open(self.csv_file, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerows(rows)
            
            messagebox.showinfo("Success", "Student deleted successfully!")
            self.load_students()
        except Exception as e:
            messagebox.showerror("Error", f"Error deleting student: {str(e)}")

    def update_face(self):
        # Step 1: Capture image from webcam
        cap = cv2.VideoCapture(0)

        print("Capturing face... Look at the camera!")

        while True:
            ret, frame = cap.read()
            if not ret:
                print("Failed to capture image")
                break

            # Detect face locations
            face_locations = face_recognition.face_locations(frame)

            # Draw green rectangle around each detected face
            for top, right, bottom, left in face_locations:
                # Draw a rectangle around the face
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)

            # Show the frame to the user
            cv2.imshow("Face Capture", frame)

            # Press 's' to save the face
            if cv2.waitKey(1) & 0xFF == ord("s"):
                break

        cap.release()
        cv2.destroyAllWindows()
        

if __name__ == "__main__":
    root = tk.Tk()
    app = StudentManagementSystem(root)
    root.mainloop()
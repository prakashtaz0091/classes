import cv2

# Load image from file
image = cv2.imread('./demo.webp')
image = cv2.resize(image, (900, 600))
image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
print(image)

# cv2.imshow('Image', image)
# cv2.waitKey(0)  # Wait for a key press
# cv2.destroyAllWindows()  # Close the window
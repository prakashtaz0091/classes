import face_recognition
import pickle


image = face_recognition.load_image_file("demo.webp")
face_encodings = face_recognition.face_encodings(image)

if len(face_encodings) == 1:
    student_id = input("Enter student symbol no: ")
    student_name = input("Enter the name of new student: ")
    student_face_encoding = face_encodings[0]
    
    new_student = {
        'id': student_id,
        'name': student_name,
        'encoding': student_face_encoding
    }
    
    # store in pickle file
    with open("student_encodings.pickle", "wb") as file:
        pickle.dump(new_student, file)
    
else:
    print("More than 1 face detected")
